from webbot import Browser
from time import sleep

web = Browser()
web.go_to("sites.google.com/view/lord-hokage-unblocked-games/home")
while True:
    sleep(0)
